/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author jeyar
 */
@Entity
public class Customer extends User {

    @OneToOne
    private CustomerProfile customerRelation;
    @OneToMany
    private List<CustomerOrder> order = new ArrayList<CustomerOrder>();

    public Customer() {
    }

    public Customer(String UserName,  String Name, int Age, String Gender, String ContactNumber,String Password) {
        super(UserName, Name, Age, Gender, ContactNumber, Password, "customer");
    }
    
    public CustomerProfile getCustomerRelation() {
        return customerRelation;
    }

    public void setCustomerRelation(CustomerProfile customerRelation) {
        this.customerRelation = customerRelation;
    }

    public List<CustomerOrder> getOrder() {
        return order;
    }

    public void setOrder(List<CustomerOrder> order) {
        this.order = order;
    }
    
}
