/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 *
 * @author jeyar
 */
@Entity
public class StallStaff extends User{
    @OneToOne
    private StaffProfile stallRelation;

    public StallStaff() {
    }

    public StallStaff(StaffProfile stallRelation, String UserName,  String Name, int Age, String Gender, String ContactNumber,String Password) {
        super(UserName, Name, Age, Gender, ContactNumber, Password, "inactive");
        this.stallRelation = stallRelation;
    }

    @Override
    public String getStatus() {
        return super.getStatus(); 
    }

    @Override
    public void setStatus(String Status) {
        super.setStatus(Status);
    }

    public StaffProfile getStallRelation() {
        return stallRelation;
    }

    public void setStallRelation(StaffProfile stallRelation) {
        this.stallRelation = stallRelation;
    }

}