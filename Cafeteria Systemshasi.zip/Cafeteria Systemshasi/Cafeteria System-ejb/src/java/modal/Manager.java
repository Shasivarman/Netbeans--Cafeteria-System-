/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

/**
 *
 * @author jeyar
 */
@Entity
public class Manager extends User{
    @OneToOne
    private ManagerProfile managerRelation;
    
    public Manager (){
    }

    public Manager(ManagerProfile managerRelation, String UserName,  String Name, int Age, String Gender, String ContactNumber,String Password) {
        super(UserName, Name, Age, Gender, ContactNumber, Password,  "manager");
        this.managerRelation = managerRelation;
    }



    public ManagerProfile getManagerRelation() {
        return managerRelation;
    }

    public void setManagerRelation(ManagerProfile managerRelation) {
        this.managerRelation = managerRelation;
    }
    
    
    
}