/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import modal.StallStaff;

/**
 *
 * @author cchie
 */
@Stateless
public class StallStaffFacade extends AbstractFacade<StallStaff> {

    @PersistenceContext(unitName = "Cafeteria_System-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StallStaffFacade() {
        super(StallStaff.class);
    }

    public StallStaff findByUsername(String userName) {
        TypedQuery<StallStaff> query = em.createQuery("SELECT u FROM User u WHERE u.userName = :userName", StallStaff.class);
        query.setParameter("userName", userName);
        List<StallStaff> result = query.getResultList();
        return result.isEmpty() ? null : result.get(0);
    }
}
