/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import modal.Menu;

/**
 *
 * @author cchie
 */
@Stateless
public class MenuFacade extends AbstractFacade<Menu> {

    @PersistenceContext(unitName = "Cafeteria_System-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public MenuFacade() {
        super(Menu.class);
    }

    public Menu findByItem(String item) {
        TypedQuery<Menu> query = em.createQuery("SELECT item FROM Menu u WHERE u.item = :item", Menu.class);
        query.setParameter("item", item);
        List<Menu> result = query.getResultList();
        return result.isEmpty() ? null : result.get(0);
    }
}
