/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import modal.Manager;

/**
 *
 * @author cchie
 */
@Stateless
public class ManagerFacade extends AbstractFacade<Manager> {

    @PersistenceContext(unitName = "Cafeteria_System-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ManagerFacade() {
        super(Manager.class);
    }

    public Manager findByUsername(String userName) {
        TypedQuery<Manager> query = em.createQuery("SELECT u FROM User u WHERE u.userName = :userName", Manager.class);
        query.setParameter("userName", userName);
        List<Manager> result = query.getResultList();
        return result.isEmpty() ? null : result.get(0);
    }
}
