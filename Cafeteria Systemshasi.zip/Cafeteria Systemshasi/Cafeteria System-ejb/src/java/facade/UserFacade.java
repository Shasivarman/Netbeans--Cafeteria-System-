/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import modal.User;

/**
 *
 * @author cchie
 */
@Stateless
public class UserFacade extends AbstractFacade<User> {

    @PersistenceContext(unitName = "Cafeteria_System-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UserFacade() {
        super(User.class);
    }

    public User findByUsername(String userName) {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.userName = :userName", User.class);
        query.setParameter("userName", userName);
        List<User> result = query.getResultList();
        return result.isEmpty() ? null : result.get(0);
    }

    public int countGender(String Gender) {
        TypedQuery<User> query = em.createQuery("SELECT u FROM User u WHERE u.Gender = :Gender", User.class);
        query.setParameter("Gender", Gender);
        List<User> result = query.getResultList();
        return result.size();
    }
}
