package Controller;

import facade.StallStaffFacade;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modal.StallStaff;

@WebServlet(urlPatterns = {"/ManagerStallStaff"})
public class ManagerStallStaff extends HttpServlet {
    @EJB
    StallStaffFacade stallFacade;
    
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String searchUsername = request.getParameter("search");
        List<StallStaff> users = stallFacade.findAll();
        if(searchUsername != null && !searchUsername.isEmpty()) {
            List<StallStaff> filteredUsers = filterStaffList(users, searchUsername);
            request.setAttribute("staffList", filteredUsers);
        } else {
            request.setAttribute("staffList", users);
        }
        System.out.println("Search is: " + users.toString());
        request.getRequestDispatcher("WEB-INF/manager/Manager_Stall.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null && !action.isEmpty()) {
            switch (action) {
                case "update":
                    updateStaff(request, response);
                    break;
                case "delete":
                    deleteStaff(request, response);
                    break;
                default:
                    response.sendRedirect("Error");
                    break;
            }
        }
    }
    
    private void updateStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String userName = request.getParameter("userName");
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        String gender = request.getParameter("gender");
        String contact_number = request.getParameter("contactNumber");
        String password = request.getParameter("password");
        String status = request.getParameter("status");
        StallStaff stallToUpdate = stallFacade.findByUsername(userName);
        stallToUpdate.setName(name);
        stallToUpdate.setAge(age);
        stallToUpdate.setGender(gender);
        stallToUpdate.setContactNumber(contact_number);
        stallToUpdate.setPassword(password);
        stallToUpdate.setStatus(status);
        stallFacade.edit(stallToUpdate);
        response.sendRedirect("ManagerStallStaff");
    }

    private void deleteStaff(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the userName of the staff to be deleted
        String userName = request.getParameter("userName");
        StallStaff stallToDelete =  stallFacade.findByUsername(userName);
        stallFacade.remove(stallToDelete);
        response.sendRedirect("ManagerStallStaff");
    }

    private List<StallStaff> filterStaffList(List<StallStaff> users, String searchUsername) {
        List<StallStaff> filteredList = new ArrayList<>();
        users.stream().filter((user) -> (user.getUserName().contains(searchUsername))).forEachOrdered((user) -> {
            filteredList.add(user);
        });
        return filteredList;
    }


}
