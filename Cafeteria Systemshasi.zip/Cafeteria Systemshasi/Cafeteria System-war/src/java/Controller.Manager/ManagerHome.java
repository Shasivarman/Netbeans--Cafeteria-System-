package Controller;
import facade.CustomerFacade;
import facade.CustomerOrderFacade;
import facade.ManagerFacade;
import facade.MenuFacade;
import facade.StallStaffFacade;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modal.CustomerOrder;


@WebServlet(urlPatterns = {"/ManagerHome"})
public class ManagerHome extends HttpServlet {
    @EJB
    ManagerFacade managerFacade;
    @EJB
    CustomerFacade customerFacade;
    @EJB
    StallStaffFacade stallFacade;
    @EJB
    MenuFacade menuFacade;
    @EJB
    CustomerOrderFacade customerorderFacade;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        List<CustomerOrder> orders = customerorderFacade.findAll();
        int[] starCounts = new int[5];
        int totalRatings = 0;
        int numberOfOrders = orders.size();
        
        for (CustomerOrder order : orders) {
            int rating = Integer.parseInt(order.getRating());
            switch (rating) {
                case 1:
                    starCounts[0]++;
                    break;
                case 2:
                    starCounts[1]++;
                    break;
                case 3:
                    starCounts[2]++;
                    break;
                case 4:
                    starCounts[3]++;
                    break;
                case 5:
                    starCounts[4]++;
                    break;
            }
        }


        for(int i=0; i<starCounts.length; i++) {
            totalRatings += (i+1) * starCounts[i];
        }
        System.out.println(totalRatings);

        double averageRating = (double) totalRatings / numberOfOrders;
        request.setAttribute("starCounts", starCounts);
        request.setAttribute("averageRating",averageRating);
        request.setAttribute("ordersCount",customerorderFacade.count());
        request.setAttribute("customersCount",customerFacade.count());
        request.setAttribute("managersCount",managerFacade.count());
        request.setAttribute("stallStaffCount",stallFacade.count());
        request.setAttribute("menusCount",menuFacade.count());
        request.getRequestDispatcher("WEB-INF/manager/Manager_Home.jsp").forward(request,response);
    }

}
