package Controller;

import facade.ManagerFacade;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modal.Manager;

@WebServlet(urlPatterns = {"/ManagerProfile"})
public class ManagerProfile extends HttpServlet {
    @EJB
    ManagerFacade managerFacade;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String)session.getAttribute("userName");
        Manager manager = managerFacade.findByUsername(userName);
        request.setAttribute("manager", manager);
        request.getRequestDispatcher("WEB-INF/manager/Manager_Profile.jsp").forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data from the request
        String userName = request.getParameter("userName");
        String contact_number = request.getParameter("contactNumber");
        String password = request.getParameter("password");
        Manager updatedManager = managerFacade.findByUsername(userName);
        updatedManager.setContactNumber(contact_number);
        updatedManager.setPassword(password);
        managerFacade.edit(updatedManager);
        
        response.sendRedirect("ManagerProfile");
    }


}
