package Controller;

import facade.CustomerFacade;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modal.Customer;

@WebServlet(urlPatterns = {"/ManagerCustomer"})
public class ManagerCustomer extends HttpServlet {
    
    @EJB
    CustomerFacade customerFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String searchUsername = request.getParameter("search");
        List<Customer> users = customerFacade.findAll();

        if (searchUsername != null && !searchUsername.isEmpty()) {
            users = filterCustomerList(users, searchUsername);
        }

        request.setAttribute("users", users);
        request.getRequestDispatcher("WEB-INF/manager/Manager_Customer.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        System.out.println("action: " + action);
        
        if ("update".equals(action)) {
            updateCustomer(request);
        } else if ("delete".equals(action)) {
            deleteCustomer(request);
        }
        
        response.sendRedirect("ManagerCustomer");
    }
    
    private void deleteCustomer(HttpServletRequest request) {
        // Delete operation
        String userName = request.getParameter("userName");
        Customer customerToDelete = customerFacade.findByUsername(userName);
        customerFacade.remove(customerToDelete);
    }

    private void updateCustomer(HttpServletRequest request) throws NumberFormatException {
        String userName = request.getParameter("userName");
        String contact_number = request.getParameter("contactNumber");
        String password = request.getParameter("password");
        
        Customer customerToUpdate = customerFacade.findByUsername(userName);
        customerToUpdate.setContactNumber(contact_number);
        customerToUpdate.setPassword(password);
        customerFacade.edit(customerToUpdate);
    }
    private List<Customer> filterCustomerList(List<Customer> users, String searchUsername) {
        List<Customer> filteredList = new ArrayList<>();
        users.stream().filter((user) -> (user.getUserName().contains(searchUsername))).forEachOrdered((user) -> {
            filteredList.add(user);
        });
        return filteredList;
    }
}
