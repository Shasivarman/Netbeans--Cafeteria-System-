package Controller;

import facade.CustomerFacade;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modal.Customer;

@WebServlet(urlPatterns = {"/CustomerProfile"})
public class CustomerProfile extends HttpServlet {
    @EJB
    CustomerFacade customerFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("userName");
        Customer customer = customerFacade.findByUsername(userName);
        request.setAttribute("customer", customer);
        request.getRequestDispatcher("WEB-INF/customer/Customer_Profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("userName");
        String contact_number = request.getParameter("contactNumber");
        String password = request.getParameter("password");
        
        Customer updatedCustomer = customerFacade.findByUsername(userName);
        updatedCustomer.setContactNumber(contact_number);
        updatedCustomer.setPassword(password);
        
        customerFacade.edit(updatedCustomer);
        
        response.sendRedirect("CustomerProfile");
    }
}
