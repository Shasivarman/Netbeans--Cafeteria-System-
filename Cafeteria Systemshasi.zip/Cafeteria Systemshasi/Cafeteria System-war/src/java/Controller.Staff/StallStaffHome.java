package Controller;

import facade.CustomerOrderFacade;
import facade.UserFacade;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modal.CustomerOrder;

@WebServlet(urlPatterns = {"/StallStaffHome"})
public class StallStaffHome extends HttpServlet {

    @EJB
    CustomerOrderFacade customerorderFacade;
    @EJB
    UserFacade userFacade;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<CustomerOrder> orders = customerorderFacade.findAll();
        int totalRatings = 0;
        int numberOfOrders = orders.size();

        totalRatings = orders.stream().map((order) -> Integer.parseInt(order.getRating())).reduce(totalRatings, Integer::sum);

        double averageRating = (double) totalRatings / numberOfOrders;
        request.setAttribute("averageRating", averageRating);
        request.setAttribute("ordersCount", customerorderFacade.count());
        request.setAttribute("femaleCount", userFacade.countGender("Female"));
        request.setAttribute("maleCount", userFacade.countGender("Male"));
        request.getRequestDispatcher("WEB-INF/stall/Stall_Home.jsp").forward(request, response);
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

}
