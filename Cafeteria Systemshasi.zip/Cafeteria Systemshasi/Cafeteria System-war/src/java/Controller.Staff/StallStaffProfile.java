package Controller;

import facade.StallStaffFacade;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modal.StallStaff;

@WebServlet(urlPatterns = {"/StallStaffProfile"})
public class StallStaffProfile extends HttpServlet {
    @EJB
    StallStaffFacade stallStaffFacade;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String)session.getAttribute("userName");
        StallStaff stallStaff = stallStaffFacade.findByUsername(userName);
        request.setAttribute("stallStaff", stallStaff);
        request.getRequestDispatcher("WEB-INF/stall/Stall_Profile.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form data from the request
        String userName = request.getParameter("userName");
        String contact_number = request.getParameter("contactNumber");
        String password = request.getParameter("password");
        
        StallStaff updatedStall = stallStaffFacade.findByUsername(userName);
        updatedStall.setContactNumber(contact_number);
        updatedStall.setPassword(password);
        
        stallStaffFacade.edit(updatedStall);
        
        response.sendRedirect("StallStaffProfile");
    }
}
